<?php
define('ROOT_PART', Root_part());
define('APIKEY', 'AIzaSyAk75W1-qg0UBp1R72-wbvJTFCiJHhAzfs');
define('GJ_CODE', 'TW');
define('SITE_NAME', 'MY');
define('TITLENAME', 'MY');
define('EN2DEKEY', 'BvlnKXOGV1');
define('EMAIL', '554325746@qq.com');
?>