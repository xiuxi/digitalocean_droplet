<?php
#$query1 = urlencode($_SERVER['QUERY_STRING']);
$query1 = $_SERVER['QUERY_STRING'];
$query = $_GET["q"];
$useragent = "Opera/9.80 (J2ME/MIDP; Opera Mini/4.2.14912/870; U; id) Presto/2.4.15";
$ch = curl_init ("");
#echo $query1;
#curl_setopt ($ch, CURLOPT_URL, "http://www.google.com/search?hl=en&tbo=d&site=&source=hp&q=".$query);
curl_setopt ($ch, CURLOPT_URL, "http://www.google.com/search?".$query1);
#curl_setopt ($ch, CURLOPT_USERAGENT, $useragent); // set user agent
curl_setopt ($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
$output = curl_exec ($ch);
$output = str_replace('/search','/test.php', $output);
$output = str_replace('/url?q=','', $output);
$output = str_replace('https://www.youtube.com/watch','http://142.93.7.158:82/watch.php', $output);
$output = str_replace('https://m.youtube.com/watch','http://142.93.7.158:82/watch.php', $output);
$output = str_replace('%3Fv%3D','?v=', $output);
$output = preg_replace("/&amp;sa=U&amp;ved=[^\"]*/i",'', $output);
echo $output;
curl_close($ch);
